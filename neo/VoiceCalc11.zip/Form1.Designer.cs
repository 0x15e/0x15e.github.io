/*
Copyright (c) 2008 Murray Melvin

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

Except as contained in this notice, the name(s) of the above 
copyright holders shall not be used in advertising or otherwise
to promote the sale, use or other dealings in this Software
without prior written authorization.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/

namespace VoiceCalc {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPasteEnglish = new System.Windows.Forms.Button();
            this.lblTicksE = new System.Windows.Forms.Label();
            this.txtEnglish = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTicksJ = new System.Windows.Forms.Label();
            this.btnPasteJapanese = new System.Windows.Forms.Button();
            this.txtJapanese = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.englishScriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptAsUTF8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptAsShiftJISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.englishScriptToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptFromUTF8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptFromShiftJISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.japaneseContext = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openFromUTF8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFromShiftJISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.japaneseContext.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.btnPasteEnglish);
            this.splitContainer1.Panel1.Controls.Add(this.lblTicksE);
            this.splitContainer1.Panel1.Controls.Add(this.txtEnglish);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.lblTicksJ);
            this.splitContainer1.Panel2.Controls.Add(this.btnPasteJapanese);
            this.splitContainer1.Panel2.Controls.Add(this.txtJapanese);
            this.splitContainer1.Size = new System.Drawing.Size(676, 403);
            this.splitContainer1.SplitterDistance = 200;
            this.splitContainer1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(287, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "English";
            // 
            // btnPasteEnglish
            // 
            this.btnPasteEnglish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPasteEnglish.Location = new System.Drawing.Point(570, 3);
            this.btnPasteEnglish.Name = "btnPasteEnglish";
            this.btnPasteEnglish.Size = new System.Drawing.Size(103, 23);
            this.btnPasteEnglish.TabIndex = 2;
            this.btnPasteEnglish.Text = "Paste English";
            this.btnPasteEnglish.UseVisualStyleBackColor = true;
            this.btnPasteEnglish.Click += new System.EventHandler(this.btnPasteEnglish_Click);
            // 
            // lblTicksE
            // 
            this.lblTicksE.AutoSize = true;
            this.lblTicksE.Location = new System.Drawing.Point(3, 8);
            this.lblTicksE.Name = "lblTicksE";
            this.lblTicksE.Size = new System.Drawing.Size(90, 13);
            this.lblTicksE.TabIndex = 0;
            this.lblTicksE.Text = "Duration:  0 ticks.";
            // 
            // txtEnglish
            // 
            this.txtEnglish.AllowDrop = true;
            this.txtEnglish.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEnglish.Font = new System.Drawing.Font("MS Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnglish.Location = new System.Drawing.Point(3, 32);
            this.txtEnglish.Multiline = true;
            this.txtEnglish.Name = "txtEnglish";
            this.txtEnglish.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtEnglish.Size = new System.Drawing.Size(670, 165);
            this.txtEnglish.TabIndex = 3;
            this.txtEnglish.WordWrap = false;
            this.txtEnglish.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtEnglish_DragDrop);
            this.txtEnglish.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtEnglish_DragEnter);
            this.txtEnglish.TextChanged += new System.EventHandler(this.txtEnglish_TextChanged);
            this.txtEnglish.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEnglish_KeyDown);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(287, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Japanese";
            // 
            // lblTicksJ
            // 
            this.lblTicksJ.AutoSize = true;
            this.lblTicksJ.Location = new System.Drawing.Point(3, 8);
            this.lblTicksJ.Name = "lblTicksJ";
            this.lblTicksJ.Size = new System.Drawing.Size(90, 13);
            this.lblTicksJ.TabIndex = 0;
            this.lblTicksJ.Text = "Duration:  0 ticks.";
            // 
            // btnPasteJapanese
            // 
            this.btnPasteJapanese.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPasteJapanese.Location = new System.Drawing.Point(570, 3);
            this.btnPasteJapanese.Name = "btnPasteJapanese";
            this.btnPasteJapanese.Size = new System.Drawing.Size(103, 23);
            this.btnPasteJapanese.TabIndex = 2;
            this.btnPasteJapanese.Text = "Paste Japanese";
            this.btnPasteJapanese.UseVisualStyleBackColor = true;
            this.btnPasteJapanese.Click += new System.EventHandler(this.btnPasteJapanese_Click);
            // 
            // txtJapanese
            // 
            this.txtJapanese.AllowDrop = true;
            this.txtJapanese.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtJapanese.Font = new System.Drawing.Font("MS Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJapanese.Location = new System.Drawing.Point(3, 32);
            this.txtJapanese.Multiline = true;
            this.txtJapanese.Name = "txtJapanese";
            this.txtJapanese.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtJapanese.Size = new System.Drawing.Size(670, 164);
            this.txtJapanese.TabIndex = 3;
            this.txtJapanese.WordWrap = false;
            this.txtJapanese.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtJapanese_DragDrop);
            this.txtJapanese.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtJapanese_DragEnter);
            this.txtJapanese.TextChanged += new System.EventHandler(this.txtJapanese_TextChanged);
            this.txtJapanese.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtJapanese_KeyDown);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(676, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.englishScriptToolStripMenuItem1,
            this.japaneseScriptFromUTF8ToolStripMenuItem,
            this.japaneseScriptFromShiftJISToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.englishScriptToolStripMenuItem,
            this.japaneseScriptAsUTF8ToolStripMenuItem,
            this.japaneseScriptAsShiftJISToolStripMenuItem});
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // englishScriptToolStripMenuItem
            // 
            this.englishScriptToolStripMenuItem.Name = "englishScriptToolStripMenuItem";
            this.englishScriptToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.englishScriptToolStripMenuItem.Text = "English Script";
            this.englishScriptToolStripMenuItem.Click += new System.EventHandler(this.englishScriptToolStripMenuItem_Click);
            // 
            // japaneseScriptAsUTF8ToolStripMenuItem
            // 
            this.japaneseScriptAsUTF8ToolStripMenuItem.Name = "japaneseScriptAsUTF8ToolStripMenuItem";
            this.japaneseScriptAsUTF8ToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.japaneseScriptAsUTF8ToolStripMenuItem.Text = "Japanese Script as UTF-8";
            this.japaneseScriptAsUTF8ToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptAsUTF8ToolStripMenuItem_Click);
            // 
            // japaneseScriptAsShiftJISToolStripMenuItem
            // 
            this.japaneseScriptAsShiftJISToolStripMenuItem.Name = "japaneseScriptAsShiftJISToolStripMenuItem";
            this.japaneseScriptAsShiftJISToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.japaneseScriptAsShiftJISToolStripMenuItem.Text = "Japanese Script as Shift-JIS";
            this.japaneseScriptAsShiftJISToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptAsShiftJISToolStripMenuItem_Click);
            // 
            // englishScriptToolStripMenuItem1
            // 
            this.englishScriptToolStripMenuItem1.Name = "englishScriptToolStripMenuItem1";
            this.englishScriptToolStripMenuItem1.Size = new System.Drawing.Size(219, 22);
            this.englishScriptToolStripMenuItem1.Text = "English Script";
            this.englishScriptToolStripMenuItem1.Click += new System.EventHandler(this.englishScriptToolStripMenuItem1_Click);
            // 
            // japaneseScriptFromUTF8ToolStripMenuItem
            // 
            this.japaneseScriptFromUTF8ToolStripMenuItem.Name = "japaneseScriptFromUTF8ToolStripMenuItem";
            this.japaneseScriptFromUTF8ToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.japaneseScriptFromUTF8ToolStripMenuItem.Text = "Japanese Script from UTF-8";
            this.japaneseScriptFromUTF8ToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptFromUTF8ToolStripMenuItem_Click);
            // 
            // japaneseScriptFromShiftJISToolStripMenuItem
            // 
            this.japaneseScriptFromShiftJISToolStripMenuItem.Name = "japaneseScriptFromShiftJISToolStripMenuItem";
            this.japaneseScriptFromShiftJISToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.japaneseScriptFromShiftJISToolStripMenuItem.Text = "Japanese Script from Shift-JIS";
            this.japaneseScriptFromShiftJISToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptFromShiftJISToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // japaneseContext
            // 
            this.japaneseContext.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openFromUTF8ToolStripMenuItem,
            this.openFromShiftJISToolStripMenuItem,
            this.toolStripSeparator2,
            this.cancelToolStripMenuItem});
            this.japaneseContext.Name = "japaneseContext";
            this.japaneseContext.Size = new System.Drawing.Size(159, 76);
            // 
            // openFromUTF8ToolStripMenuItem
            // 
            this.openFromUTF8ToolStripMenuItem.Name = "openFromUTF8ToolStripMenuItem";
            this.openFromUTF8ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.openFromUTF8ToolStripMenuItem.Text = "Open as UTF-8";
            this.openFromUTF8ToolStripMenuItem.Click += new System.EventHandler(this.openFromUTF8ToolStripMenuItem_Click);
            // 
            // openFromShiftJISToolStripMenuItem
            // 
            this.openFromShiftJISToolStripMenuItem.Name = "openFromShiftJISToolStripMenuItem";
            this.openFromShiftJISToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.openFromShiftJISToolStripMenuItem.Text = "Open as Shift-JIS";
            this.openFromShiftJISToolStripMenuItem.Click += new System.EventHandler(this.openFromShiftJISToolStripMenuItem_Click);
            // 
            // cancelToolStripMenuItem
            // 
            this.cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
            this.cancelToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.cancelToolStripMenuItem.Text = "Cancel";
            this.cancelToolStripMenuItem.Click += new System.EventHandler(this.cancelToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(155, 6);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 427);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Voice Script Duration Calculator";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.japaneseContext.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtEnglish;
        private System.Windows.Forms.TextBox txtJapanese;
        private System.Windows.Forms.Button btnPasteEnglish;
        private System.Windows.Forms.Label lblTicksE;
        private System.Windows.Forms.Button btnPasteJapanese;
        private System.Windows.Forms.Label lblTicksJ;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishScriptToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptFromUTF8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptFromShiftJISToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishScriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptAsUTF8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptAsShiftJISToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ContextMenuStrip japaneseContext;
        private System.Windows.Forms.ToolStripMenuItem openFromUTF8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openFromShiftJISToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem cancelToolStripMenuItem;


    }
}

