namespace VoiceCalc {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPasteEnglish = new System.Windows.Forms.Button();
            this.lblTicksE = new System.Windows.Forms.Label();
            this.txtEnglish = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTicksJ = new System.Windows.Forms.Label();
            this.btnPasteJapanese = new System.Windows.Forms.Button();
            this.txtJapanese = new System.Windows.Forms.TextBox();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.btnPasteEnglish);
            this.splitContainer1.Panel1.Controls.Add(this.lblTicksE);
            this.splitContainer1.Panel1.Controls.Add(this.txtEnglish);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.lblTicksJ);
            this.splitContainer1.Panel2.Controls.Add(this.btnPasteJapanese);
            this.splitContainer1.Panel2.Controls.Add(this.txtJapanese);
            this.splitContainer1.Size = new System.Drawing.Size(681, 355);
            this.splitContainer1.SplitterDistance = 177;
            this.splitContainer1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(289, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "English";
            // 
            // btnPasteEnglish
            // 
            this.btnPasteEnglish.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPasteEnglish.Location = new System.Drawing.Point(575, 3);
            this.btnPasteEnglish.Name = "btnPasteEnglish";
            this.btnPasteEnglish.Size = new System.Drawing.Size(103, 23);
            this.btnPasteEnglish.TabIndex = 2;
            this.btnPasteEnglish.Text = "Paste English";
            this.btnPasteEnglish.UseVisualStyleBackColor = true;
            this.btnPasteEnglish.Click += new System.EventHandler(this.btnPasteEnglish_Click);
            // 
            // lblTicksE
            // 
            this.lblTicksE.AutoSize = true;
            this.lblTicksE.Location = new System.Drawing.Point(3, 8);
            this.lblTicksE.Name = "lblTicksE";
            this.lblTicksE.Size = new System.Drawing.Size(90, 13);
            this.lblTicksE.TabIndex = 0;
            this.lblTicksE.Text = "Duration:  0 ticks.";
            // 
            // txtEnglish
            // 
            this.txtEnglish.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEnglish.Font = new System.Drawing.Font("MS Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnglish.Location = new System.Drawing.Point(3, 32);
            this.txtEnglish.Multiline = true;
            this.txtEnglish.Name = "txtEnglish";
            this.txtEnglish.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtEnglish.Size = new System.Drawing.Size(675, 142);
            this.txtEnglish.TabIndex = 3;
            this.txtEnglish.WordWrap = false;
            this.txtEnglish.TextChanged += new System.EventHandler(this.txtEnglish_TextChanged);
            this.txtEnglish.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEnglish_KeyDown);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(289, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Japanese";
            // 
            // lblTicksJ
            // 
            this.lblTicksJ.AutoSize = true;
            this.lblTicksJ.Location = new System.Drawing.Point(3, 8);
            this.lblTicksJ.Name = "lblTicksJ";
            this.lblTicksJ.Size = new System.Drawing.Size(90, 13);
            this.lblTicksJ.TabIndex = 0;
            this.lblTicksJ.Text = "Duration:  0 ticks.";
            // 
            // btnPasteJapanese
            // 
            this.btnPasteJapanese.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPasteJapanese.Location = new System.Drawing.Point(575, 3);
            this.btnPasteJapanese.Name = "btnPasteJapanese";
            this.btnPasteJapanese.Size = new System.Drawing.Size(103, 23);
            this.btnPasteJapanese.TabIndex = 2;
            this.btnPasteJapanese.Text = "Paste Japanese";
            this.btnPasteJapanese.UseVisualStyleBackColor = true;
            this.btnPasteJapanese.Click += new System.EventHandler(this.btnPasteJapanese_Click);
            // 
            // txtJapanese
            // 
            this.txtJapanese.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtJapanese.Font = new System.Drawing.Font("MS Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJapanese.Location = new System.Drawing.Point(3, 32);
            this.txtJapanese.Multiline = true;
            this.txtJapanese.Name = "txtJapanese";
            this.txtJapanese.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtJapanese.Size = new System.Drawing.Size(675, 139);
            this.txtJapanese.TabIndex = 3;
            this.txtJapanese.WordWrap = false;
            this.txtJapanese.TextChanged += new System.EventHandler(this.txtJapanese_TextChanged);
            this.txtJapanese.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtJapanese_KeyDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 355);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Voice Script Duration Calculator";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtEnglish;
        private System.Windows.Forms.TextBox txtJapanese;
        private System.Windows.Forms.Button btnPasteEnglish;
        private System.Windows.Forms.Label lblTicksE;
        private System.Windows.Forms.Button btnPasteJapanese;
        private System.Windows.Forms.Label lblTicksJ;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;


    }
}

