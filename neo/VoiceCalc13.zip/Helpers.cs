using System;
using System.Collections.Generic;
using System.Text;

namespace VoiceCalc {
    internal class Helpers {
        public static int FindBeginningOfLine(string text, int backFromIndex) {
            if (backFromIndex < 0) throw new ArgumentOutOfRangeException();

            string lineCmd = "<line>";
            int lineCmdIndex = text.LastIndexOf(lineCmd, backFromIndex, backFromIndex + 1, StringComparison.CurrentCultureIgnoreCase);

            return lineCmdIndex >= 0 ? lineCmdIndex + lineCmd.Length : 0;
        }
    }
}
