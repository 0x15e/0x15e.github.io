/*
Copyright (c) 2008 Murray Melvin

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

Except as contained in this notice, the name(s) of the above 
copyright holders shall not be used in advertising or otherwise
to promote the sale, use or other dealings in this Software
without prior written authorization.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/

namespace VoiceCalc {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.englishDuration = new System.Windows.Forms.ToolStripStatusLabel();
            this.englishColumn = new System.Windows.Forms.ToolStripStatusLabel();
            this.englishTile = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.englishError = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.englishPaste = new System.Windows.Forms.ToolStripDropDownButton();
            this.txtEnglish = new System.Windows.Forms.TextBox();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.japaneseDuration = new System.Windows.Forms.ToolStripStatusLabel();
            this.japaneseColumn = new System.Windows.Forms.ToolStripStatusLabel();
            this.japaneseTile = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.japaneseError = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel8 = new System.Windows.Forms.ToolStripStatusLabel();
            this.japanesePaste = new System.Windows.Forms.ToolStripSplitButton();
            this.jpPasteContext = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pasteAsUTF8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteAsShiftJISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtJapanese = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.englishScriptToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptFromUTF8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptFromShiftJISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.englishScriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptAsUTF8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.japaneseScriptAsShiftJISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.japaneseContext = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openFromUTF8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFromShiftJISToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cancelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.jpPasteContext.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.japaneseContext.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.statusStrip1);
            this.splitContainer1.Panel1.Controls.Add(this.txtEnglish);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.statusStrip2);
            this.splitContainer1.Panel2.Controls.Add(this.txtJapanese);
            this.splitContainer1.Size = new System.Drawing.Size(676, 444);
            this.splitContainer1.SplitterDistance = 220;
            this.splitContainer1.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.englishDuration,
            this.englishColumn,
            this.englishTile,
            this.toolStripStatusLabel2,
            this.englishError,
            this.toolStripStatusLabel3,
            this.englishPaste});
            this.statusStrip1.Location = new System.Drawing.Point(0, 198);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(676, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "englishStatus";
            // 
            // englishDuration
            // 
            this.englishDuration.Name = "englishDuration";
            this.englishDuration.Size = new System.Drawing.Size(92, 17);
            this.englishDuration.Text = "Duration:  0 ticks.";
            // 
            // englishColumn
            // 
            this.englishColumn.Name = "englishColumn";
            this.englishColumn.Size = new System.Drawing.Size(62, 17);
            this.englishColumn.Text = "Column:  0.";
            this.englishColumn.Visible = false;
            // 
            // englishTile
            // 
            this.englishTile.Name = "englishTile";
            this.englishTile.Size = new System.Drawing.Size(43, 17);
            this.englishTile.Text = "Tile:  0.";
            this.englishTile.Visible = false;
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(491, 17);
            this.toolStripStatusLabel2.Spring = true;
            // 
            // englishError
            // 
            this.englishError.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.englishError.Name = "englishError";
            this.englishError.Size = new System.Drawing.Size(31, 17);
            this.englishError.Text = "Error";
            this.englishError.Visible = false;
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(40, 17);
            this.toolStripStatusLabel3.Text = "English";
            // 
            // englishPaste
            // 
            this.englishPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.englishPaste.Image = ((System.Drawing.Image)(resources.GetObject("englishPaste.Image")));
            this.englishPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.englishPaste.Name = "englishPaste";
            this.englishPaste.ShowDropDownArrow = false;
            this.englishPaste.Size = new System.Drawing.Size(38, 20);
            this.englishPaste.Text = "Paste";
            this.englishPaste.Click += new System.EventHandler(this.btnPasteEnglish_Click);
            // 
            // txtEnglish
            // 
            this.txtEnglish.AllowDrop = true;
            this.txtEnglish.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEnglish.Font = new System.Drawing.Font("MS Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnglish.Location = new System.Drawing.Point(3, 3);
            this.txtEnglish.Multiline = true;
            this.txtEnglish.Name = "txtEnglish";
            this.txtEnglish.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtEnglish.Size = new System.Drawing.Size(670, 192);
            this.txtEnglish.TabIndex = 3;
            this.txtEnglish.WordWrap = false;
            this.txtEnglish.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtEnglish_DragDrop);
            this.txtEnglish.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtEnglish_DragEnter);
            this.txtEnglish.TextChanged += new System.EventHandler(this.txtEnglish_TextChanged);
            this.txtEnglish.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEnglish_KeyDown);
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.japaneseDuration,
            this.japaneseColumn,
            this.japaneseTile,
            this.toolStripStatusLabel7,
            this.japaneseError,
            this.toolStripStatusLabel8,
            this.japanesePaste});
            this.statusStrip2.Location = new System.Drawing.Point(0, 198);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(676, 22);
            this.statusStrip2.SizingGrip = false;
            this.statusStrip2.TabIndex = 5;
            this.statusStrip2.Text = "englishStatus";
            // 
            // japaneseDuration
            // 
            this.japaneseDuration.Name = "japaneseDuration";
            this.japaneseDuration.Size = new System.Drawing.Size(92, 17);
            this.japaneseDuration.Text = "Duration:  0 ticks.";
            // 
            // japaneseColumn
            // 
            this.japaneseColumn.Name = "japaneseColumn";
            this.japaneseColumn.Size = new System.Drawing.Size(62, 17);
            this.japaneseColumn.Text = "Column:  0.";
            this.japaneseColumn.Visible = false;
            // 
            // japaneseTile
            // 
            this.japaneseTile.Name = "japaneseTile";
            this.japaneseTile.Size = new System.Drawing.Size(43, 17);
            this.japaneseTile.Text = "Tile:  0.";
            this.japaneseTile.Visible = false;
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(466, 17);
            this.toolStripStatusLabel7.Spring = true;
            // 
            // japaneseError
            // 
            this.japaneseError.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.japaneseError.Name = "japaneseError";
            this.japaneseError.Size = new System.Drawing.Size(31, 17);
            this.japaneseError.Text = "Error";
            this.japaneseError.Visible = false;
            // 
            // toolStripStatusLabel8
            // 
            this.toolStripStatusLabel8.Name = "toolStripStatusLabel8";
            this.toolStripStatusLabel8.Size = new System.Drawing.Size(53, 17);
            this.toolStripStatusLabel8.Text = "Japanese";
            // 
            // japanesePaste
            // 
            this.japanesePaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.japanesePaste.DropDown = this.jpPasteContext;
            this.japanesePaste.Image = ((System.Drawing.Image)(resources.GetObject("japanesePaste.Image")));
            this.japanesePaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.japanesePaste.Name = "japanesePaste";
            this.japanesePaste.Size = new System.Drawing.Size(50, 20);
            this.japanesePaste.Text = "Paste";
            this.japanesePaste.ButtonClick += new System.EventHandler(this.btnPasteJapanese_Click);
            // 
            // jpPasteContext
            // 
            this.jpPasteContext.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pasteAsUTF8ToolStripMenuItem,
            this.pasteAsShiftJISToolStripMenuItem});
            this.jpPasteContext.Name = "jpPasteContext";
            this.jpPasteContext.OwnerItem = this.japanesePaste;
            this.jpPasteContext.Size = new System.Drawing.Size(160, 48);
            // 
            // pasteAsUTF8ToolStripMenuItem
            // 
            this.pasteAsUTF8ToolStripMenuItem.Name = "pasteAsUTF8ToolStripMenuItem";
            this.pasteAsUTF8ToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.pasteAsUTF8ToolStripMenuItem.Text = "Paste as UTF-8";
            this.pasteAsUTF8ToolStripMenuItem.Click += new System.EventHandler(this.pasteAsUTF8ToolStripMenuItem_Click);
            // 
            // pasteAsShiftJISToolStripMenuItem
            // 
            this.pasteAsShiftJISToolStripMenuItem.Name = "pasteAsShiftJISToolStripMenuItem";
            this.pasteAsShiftJISToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.pasteAsShiftJISToolStripMenuItem.Text = "Paste as Shift-JIS";
            this.pasteAsShiftJISToolStripMenuItem.Click += new System.EventHandler(this.pasteAsShiftJISToolStripMenuItem_Click);
            // 
            // txtJapanese
            // 
            this.txtJapanese.AllowDrop = true;
            this.txtJapanese.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtJapanese.Font = new System.Drawing.Font("MS Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJapanese.Location = new System.Drawing.Point(3, 3);
            this.txtJapanese.Multiline = true;
            this.txtJapanese.Name = "txtJapanese";
            this.txtJapanese.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtJapanese.Size = new System.Drawing.Size(670, 192);
            this.txtJapanese.TabIndex = 3;
            this.txtJapanese.WordWrap = false;
            this.txtJapanese.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtJapanese_DragDrop);
            this.txtJapanese.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtJapanese_DragEnter);
            this.txtJapanese.TextChanged += new System.EventHandler(this.txtJapanese_TextChanged);
            this.txtJapanese.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtJapanese_KeyDown);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(676, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.englishScriptToolStripMenuItem1,
            this.japaneseScriptFromUTF8ToolStripMenuItem,
            this.japaneseScriptFromShiftJISToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // englishScriptToolStripMenuItem1
            // 
            this.englishScriptToolStripMenuItem1.Name = "englishScriptToolStripMenuItem1";
            this.englishScriptToolStripMenuItem1.Size = new System.Drawing.Size(219, 22);
            this.englishScriptToolStripMenuItem1.Text = "English Script";
            this.englishScriptToolStripMenuItem1.Click += new System.EventHandler(this.englishScriptToolStripMenuItem1_Click);
            // 
            // japaneseScriptFromUTF8ToolStripMenuItem
            // 
            this.japaneseScriptFromUTF8ToolStripMenuItem.Name = "japaneseScriptFromUTF8ToolStripMenuItem";
            this.japaneseScriptFromUTF8ToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.japaneseScriptFromUTF8ToolStripMenuItem.Text = "Japanese Script from UTF-8";
            this.japaneseScriptFromUTF8ToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptFromUTF8ToolStripMenuItem_Click);
            // 
            // japaneseScriptFromShiftJISToolStripMenuItem
            // 
            this.japaneseScriptFromShiftJISToolStripMenuItem.Name = "japaneseScriptFromShiftJISToolStripMenuItem";
            this.japaneseScriptFromShiftJISToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.japaneseScriptFromShiftJISToolStripMenuItem.Text = "Japanese Script from Shift-JIS";
            this.japaneseScriptFromShiftJISToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptFromShiftJISToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.englishScriptToolStripMenuItem,
            this.japaneseScriptAsUTF8ToolStripMenuItem,
            this.japaneseScriptAsShiftJISToolStripMenuItem});
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.saveToolStripMenuItem.Text = "Save";
            // 
            // englishScriptToolStripMenuItem
            // 
            this.englishScriptToolStripMenuItem.Name = "englishScriptToolStripMenuItem";
            this.englishScriptToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.S)));
            this.englishScriptToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.englishScriptToolStripMenuItem.Text = "English Script";
            this.englishScriptToolStripMenuItem.Click += new System.EventHandler(this.englishScriptToolStripMenuItem_Click);
            // 
            // japaneseScriptAsUTF8ToolStripMenuItem
            // 
            this.japaneseScriptAsUTF8ToolStripMenuItem.Name = "japaneseScriptAsUTF8ToolStripMenuItem";
            this.japaneseScriptAsUTF8ToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.japaneseScriptAsUTF8ToolStripMenuItem.Text = "Japanese Script as UTF-8";
            this.japaneseScriptAsUTF8ToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptAsUTF8ToolStripMenuItem_Click);
            // 
            // japaneseScriptAsShiftJISToolStripMenuItem
            // 
            this.japaneseScriptAsShiftJISToolStripMenuItem.Name = "japaneseScriptAsShiftJISToolStripMenuItem";
            this.japaneseScriptAsShiftJISToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.japaneseScriptAsShiftJISToolStripMenuItem.Text = "Japanese Script as Shift-JIS";
            this.japaneseScriptAsShiftJISToolStripMenuItem.Click += new System.EventHandler(this.japaneseScriptAsShiftJISToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(97, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // japaneseContext
            // 
            this.japaneseContext.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openFromUTF8ToolStripMenuItem,
            this.openFromShiftJISToolStripMenuItem,
            this.toolStripSeparator2,
            this.cancelToolStripMenuItem});
            this.japaneseContext.Name = "japaneseContext";
            this.japaneseContext.Size = new System.Drawing.Size(159, 76);
            // 
            // openFromUTF8ToolStripMenuItem
            // 
            this.openFromUTF8ToolStripMenuItem.Name = "openFromUTF8ToolStripMenuItem";
            this.openFromUTF8ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.openFromUTF8ToolStripMenuItem.Text = "Open as UTF-8";
            this.openFromUTF8ToolStripMenuItem.Click += new System.EventHandler(this.openFromUTF8ToolStripMenuItem_Click);
            // 
            // openFromShiftJISToolStripMenuItem
            // 
            this.openFromShiftJISToolStripMenuItem.Name = "openFromShiftJISToolStripMenuItem";
            this.openFromShiftJISToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.openFromShiftJISToolStripMenuItem.Text = "Open as Shift-JIS";
            this.openFromShiftJISToolStripMenuItem.Click += new System.EventHandler(this.openFromShiftJISToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(155, 6);
            // 
            // cancelToolStripMenuItem
            // 
            this.cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
            this.cancelToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.cancelToolStripMenuItem.Text = "Cancel";
            this.cancelToolStripMenuItem.Click += new System.EventHandler(this.cancelToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(676, 468);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Voice Script Duration Calculator";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.jpPasteContext.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.japaneseContext.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtEnglish;
        private System.Windows.Forms.TextBox txtJapanese;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishScriptToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptFromUTF8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptFromShiftJISToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishScriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptAsUTF8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem japaneseScriptAsShiftJISToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ContextMenuStrip japaneseContext;
        private System.Windows.Forms.ToolStripMenuItem openFromUTF8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openFromShiftJISToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem cancelToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip jpPasteContext;
        private System.Windows.Forms.ToolStripMenuItem pasteAsUTF8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteAsShiftJISToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel englishDuration;
        private System.Windows.Forms.ToolStripStatusLabel englishColumn;
        private System.Windows.Forms.ToolStripStatusLabel englishTile;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel japaneseDuration;
        private System.Windows.Forms.ToolStripStatusLabel japaneseColumn;
        private System.Windows.Forms.ToolStripStatusLabel japaneseTile;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel8;
        private System.Windows.Forms.ToolStripDropDownButton englishPaste;
        private System.Windows.Forms.ToolStripSplitButton japanesePaste;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripStatusLabel englishError;
        private System.Windows.Forms.ToolStripStatusLabel japaneseError;


    }
}

