using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Text;
using System.Windows.Forms;

namespace VoiceCalc {
    public partial class Form1 : Form {
        const int DEFAULT_TICKS_PER_TILE = 1;
        const int TICKS_PER_PAUSE = 7;

        protected object LOCK_CALC_ENGLISH = false;
        protected object LOCK_CALC_JAPANESE = false;

        public Form1() {
            InitializeComponent();
        }

        private void txtEnglish_TextChanged(object sender, EventArgs e) {
            lock (LOCK_CALC_ENGLISH) {
                int errors = 0;

                string workText = txtEnglish.Text.Replace("\r", String.Empty).Replace("\n", String.Empty);

                SetText(englishDuration, String.Format(Messages.Duration, CalculateDuration(workText, 2, out errors)));

                // if (errors > 0) ShowMessageBox(this, Messages.ErrorsDuringCalc);
                SetVisible(englishError, errors > 0);
            }
        }

        delegate void ShowMessageBoxDelegate(Form frm, string text);
        private void ShowMessageBox(Form frm, string text) {
            if (frm.InvokeRequired) {
                ShowMessageBoxDelegate d = new ShowMessageBoxDelegate(ShowMessageBox);
                this.Invoke(d, new object[] { frm, text });
            }
            else {
                MessageBox.Show(frm, text);
            }
        }

        delegate void SetVisibleDelegate(ToolStripItem tsi, bool visible);
        private void SetVisible(ToolStripItem tsi, bool visible) {
            if (this.InvokeRequired) {
                SetVisibleDelegate d = new SetVisibleDelegate(SetVisible);
                this.Invoke(d, new object[] { tsi, visible });
            }
            else {
                tsi.Visible = visible;
            }
        }

        delegate void SetToolTipDelegate(ToolStripItem tsi, string text);
        private void SetToolTip(ToolStripItem tsi, string text) {
            if (this.InvokeRequired) {
                SetToolTipDelegate d = new SetToolTipDelegate(SetToolTip);
                this.Invoke(d, new object[] { tsi, text });
            }
            else {
                tsi.ToolTipText = text;
            }
        }

        delegate void SetTextDelegate(object o, string text);
        private void SetText(object o, string text) {
            if (o is ToolStripItem) {
                ToolStripItem tsi = o as ToolStripItem;
                if (this.InvokeRequired) {
                    SetTextDelegate d = new SetTextDelegate(SetText);
                    this.Invoke(d, new object[] { tsi, text });
                }
                else {
                    tsi.Text = text;
                }
            }
            else if (o is Control) {
                Control ctl = o as Control;
                if (ctl.InvokeRequired) {
                    SetTextDelegate d = new SetTextDelegate(SetText);
                    this.Invoke(d, new object[] { ctl, text });
                }
                else {
                    ctl.Text = text;
                }
            }
        }

        delegate void SetSelStartDelegate(TextBox box, int selStart);
        private void SetSelStart(TextBox box, int selStart) {
            if (box.InvokeRequired) {
                SetSelStartDelegate d = new SetSelStartDelegate(SetSelStart);
                this.Invoke(d, new object[] { box, selStart });
            }
            else {
                box.SelectionStart = selStart;
            }
        }

        private long CalculateDuration(string text, short charsPerTile, out int errorCount) {
            if (charsPerTile < 1 || charsPerTile > 2) throw new ArgumentOutOfRangeException("charsPerTile", "You can only have 1 or 2 characters per tile.");

            long duration = 0;
            int curTicksPerTile = DEFAULT_TICKS_PER_TILE;
            errorCount = 0;

            Regex re = new Regex(Expressions.Commands, RegexOptions.IgnoreCase);
            MatchCollection mc = re.Matches(text);

            // special case
            // there are no matches, but there is text. calculate with the defaults and return
            if (mc.Count == 0 && !String.IsNullOrEmpty(text)) {
                return Convert.ToInt64(GetTileCount(charsPerTile, text) * DEFAULT_TICKS_PER_TILE);
            }

            int stringPos = 0;
            
            for (int i = 0; i < mc.Count; i++) {
                Match curMatch = mc[i];
                Match prevMatch = i == 0 ? null : mc[i - 1];

                stringPos = curMatch.Index + curMatch.Length;

                // is there a previous command?
                // if so, how many raw characters between it and the current one?
                if (prevMatch != null) {
                    int rawCount = curMatch.Index - (prevMatch.Index + prevMatch.Length);

                    // if there were any raw characters, we need to calculate their render time using the current speed
                    if (rawCount > 0) {
                        string subString = text.Substring(prevMatch.Index + prevMatch.Length, rawCount);
                        int tileCount = GetTileCount(charsPerTile, subString);
                        Debug.WriteLine(String.Format(Messages.DurationAdd, Convert.ToInt64(curTicksPerTile * tileCount).ToString(), subString));
                        duration += Convert.ToInt64(curTicksPerTile * tileCount);
                    }
                }
                else if (curMatch.Index > 0) {
                    // this is the first time through and there are characters before this command
                    string subString = text.Substring(0, curMatch.Index);
                    int tileCount = GetTileCount(charsPerTile, subString);
                    Debug.WriteLine(String.Format(Messages.DurationAdd, Convert.ToInt64(curTicksPerTile * tileCount).ToString(), subString));
                    duration += Convert.ToInt64(curTicksPerTile * tileCount);
                }

                if (curMatch.Value.ToLower().StartsWith("<p>")) {
                    // is the current command a pause?
                    // if so, add the pause length to the duration
                    if (curMatch.Length == 3) {
                        // if it's just a basic pause, add TICKS_PER_PAUSE
                        Debug.WriteLine(String.Format(Messages.DurationAdd, TICKS_PER_PAUSE, curMatch.Value));
                        duration += TICKS_PER_PAUSE;
                    }
                    else {
                        // otherwise, this pause has SPEED power! go, Go, GO!
                        // get the speed duration and add it instead of TICKS_PER_PAUSE
                        int speedError = 0;
                        int speed = CalculateSpeed(curMatch.Value, out speedError);
                        Debug.WriteLine(String.Format(Messages.DurationAdd, speed, curMatch.Value));
                        duration += speed;
                        errorCount += speedError;
                    }
                }
                else if (curMatch.Value.ToLower().StartsWith("<speed>")) {
                    // is the current command a speed?
                    // if so, set the current speed to the specified one
                    int speedError = 0;
                    int newSpeed = CalculateSpeed(curMatch.Value, out speedError);
                    errorCount += speedError;
                    if (newSpeed == 0) {
                        curTicksPerTile = DEFAULT_TICKS_PER_TILE;
                    }
                    else {
                        curTicksPerTile = newSpeed;
                    }
                }
                else {
                    // don't care about other commands, so don't add anything to the duration for now
                }

            }

            if (stringPos < text.Length) {
                // there is bare text after all the commands.  where's the stop?
                string subString = text.Substring(stringPos);
                int tileCount = GetTileCount(charsPerTile, subString);
                Debug.WriteLine(String.Format(Messages.DurationAdd, Convert.ToInt64(curTicksPerTile * tileCount).ToString(), subString));
                duration += Convert.ToInt64(curTicksPerTile * tileCount);
            }

            return duration;
        }

        private static int GetTileCount(short charsPerTile, string subString) {
            int tileCount = 0;
            if (charsPerTile == 1) {
                tileCount = subString.Length;
            }
            else {
                tileCount = Convert.ToInt32(Math.Ceiling((double)(Convert.ToSingle(subString.Length) / Convert.ToSingle(charsPerTile))));
            }
            return tileCount;
        }

        private int CalculateSpeed(string speedCmdString, out int error) {
            int retVal = 0;
            error = 0;

            Match m = Regex.Match(speedCmdString, Expressions.SpeedCommand, RegexOptions.IgnoreCase);
            if (m.Length > 0) {
                string firstParmByte = m.Groups["firstParmByte"].Value;
                string secParmByte = m.Groups["secParmByte"].Value;
                if (!int.TryParse(firstParmByte + secParmByte, System.Globalization.NumberStyles.HexNumber, System.Globalization.CultureInfo.CurrentCulture.NumberFormat, out retVal)) {
                    retVal = 0;
                    Debug.WriteLine(String.Format(Messages.SpeedArgsFail, speedCmdString));
                    error++;
                }
            }
            else {
                // wtf.
                Debug.WriteLine(String.Format(Messages.SpeedParseFail, speedCmdString));
                error++;
            }

            return retVal;
        }

        private void txtJapanese_TextChanged(object sender, EventArgs e) {
            lock (LOCK_CALC_JAPANESE) {
                string workText = txtJapanese.Text.Replace("\r", String.Empty).Replace("\n", String.Empty);
                int errors = 0;

                SetText(japaneseDuration, String.Format(Messages.Duration, CalculateDuration(workText, 1, out errors)));

                // if (errors > 0) ShowMessageBox(this, Messages.ErrorsDuringCalc);
                SetVisible(japaneseError, errors > 0);
            }
        }

        private void btnPasteEnglish_Click(object sender, EventArgs e) {
            if (Clipboard.ContainsText()) {
                SetText(txtEnglish, Clipboard.GetText());
            }
        }

        private void btnPasteJapanese_Click(object sender, EventArgs e) {
            pasteAsUTF8ToolStripMenuItem_Click(sender, e);
        }

        private void txtEnglish_KeyDown(object sender, KeyEventArgs e) {
            if (e.Control && !(e.Alt || e.Shift) && e.KeyCode == Keys.A) {
                txtEnglish.SelectAll();
                e.Handled = true;
                e.SuppressKeyPress = true;
                return;
            }

            if (e.Control && !(e.Alt || e.Shift) && e.KeyCode == Keys.P) {
                int selStart = txtEnglish.SelectionStart;
                SetText(txtEnglish, txtEnglish.Text.Insert(selStart, "<P>"));
                SetSelStart(txtEnglish, selStart + 3);
                e.Handled = true;
                e.SuppressKeyPress = true;
                return;
            }

            if (e.Control && !(e.Alt || e.Shift) && e.KeyCode == Keys.R) {
                int selStart = txtEnglish.SelectionStart;
                SetText(txtEnglish, txtEnglish.Text.Insert(selStart, "<$00><$>"));
                SetSelStart(txtEnglish, selStart + 7);
                e.Handled = true;
                e.SuppressKeyPress = true;
                return;
            }

            if (e.Control && !(e.Alt || e.Shift) && e.KeyCode == Keys.S) {
                int selStart = txtEnglish.SelectionStart;
                SetText(txtEnglish, txtEnglish.Text.Insert(selStart, "<SPEED>"));
                SetSelStart(txtEnglish, selStart + 7);
                e.Handled = true;
                e.SuppressKeyPress = true;
                return;
            }
        }

        private void txtJapanese_KeyDown(object sender, KeyEventArgs e) {
            if (e.Control && !(e.Alt || e.Shift) && e.KeyCode == Keys.A) {
                txtJapanese.SelectAll();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void englishScriptToolStripMenuItem1_Click(object sender, EventArgs e) {
            lock (openFileDialog1) {
                DialogResult dr = openFileDialog1.ShowDialog(this);
                if (dr != DialogResult.Cancel) {
                    string text = ReadUTF8TextFile(openFileDialog1.FileName);
                    SetText(txtEnglish, text);
                }
            }
        }

        private string ReadUTF8TextFile(string fileName) {
            string text = String.Empty;

            try {
                FileInfo fi = new FileInfo(fileName);
                if (fi.Exists) {
                    TextReader tr = fi.OpenText();
                    text = tr.ReadToEnd();
                    tr.Close();
                    tr.Dispose();
                }
            }
            catch (Exception ex) {
                text = ex.ToString();
            }

            return text;
        }

        private void japaneseScriptFromUTF8ToolStripMenuItem_Click(object sender, EventArgs e) {
            lock (openFileDialog1) {
                DialogResult dr = openFileDialog1.ShowDialog(this);
                if (dr != DialogResult.Cancel) {
                    string text = ReadUTF8TextFile(openFileDialog1.FileName);
                    SetText(txtJapanese, text);
                }
            }
        }

        private void japaneseScriptFromShiftJISToolStripMenuItem_Click(object sender, EventArgs e) {
            lock (openFileDialog1) {
                DialogResult dr = openFileDialog1.ShowDialog(this);
                if (dr != DialogResult.Cancel) {
                    string text = ReadShiftJISTextFile(openFileDialog1.FileName);
                    SetText(txtJapanese, text);
                }
            }
        }

        private string ReadShiftJISTextFile(string fileName) {
            string text = String.Empty;

            try {
                FileInfo fi = new FileInfo(fileName);
                if (fi.Exists) {
                    FileStream fs = fi.OpenRead();
                    StreamReader sr = new StreamReader(fs, System.Text.Encoding.GetEncoding("Shift-Jis"));
                    text = sr.ReadToEnd();
                    sr.Close();
                    sr.Dispose();
                    fs.Dispose();
                }
            }
            catch (Exception ex) {
                text = ex.ToString();
            }

            return text;
        }

        private void txtJapanese_DragEnter(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                e.Effect = DragDropEffects.Copy;
            }
            else {
                e.Effect = DragDropEffects.None;
            }
        }

        private string _droppedJpFileName = String.Empty;
        private void txtJapanese_DragDrop(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                string[] data = (string[])e.Data.GetData(DataFormats.FileDrop);
                _droppedJpFileName = data[0];
                japaneseContext.Show(new Point(e.X, e.Y));
            }
        }

        private void openFromUTF8ToolStripMenuItem_Click(object sender, EventArgs e) {
            string text = ReadUTF8TextFile(_droppedJpFileName);
            SetText(txtJapanese, text);
            _droppedJpFileName = String.Empty;
        }

        private void openFromShiftJISToolStripMenuItem_Click(object sender, EventArgs e) {
            string text = ReadShiftJISTextFile(_droppedJpFileName);
            SetText(txtJapanese, text);
            _droppedJpFileName = String.Empty;
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e) {
            _droppedJpFileName = String.Empty;
        }

        private void txtEnglish_DragEnter(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                e.Effect = DragDropEffects.Copy;
            }
            else {
                e.Effect = DragDropEffects.None;
            }
        }

        private void txtEnglish_DragDrop(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                string[] data = (string[])e.Data.GetData(DataFormats.FileDrop);
                string text = ReadUTF8TextFile(data[0]);
                SetText(txtEnglish, text);
            }
        }

        private void englishScriptToolStripMenuItem_Click(object sender, EventArgs e) {
            DialogResult dr = saveFileDialog1.ShowDialog(this);
            if (dr != DialogResult.Cancel) {
                string error = SaveUTF8File(saveFileDialog1.FileName, txtEnglish.Text);
                if (!String.IsNullOrEmpty(error)) {
                    ShowMessageBox(this, error);
                }
            }
        }

        private string SaveUTF8File(string fileName, string text) {
            try {
                FileInfo fi = new FileInfo(fileName);
                FileStream fs = fi.OpenWrite();
                byte[] bytes = Encoding.UTF8.GetBytes(text);
                fs.Write(bytes, 0, bytes.Length);
                fs.Close();
                fs.Dispose();
                return String.Empty;
            }
            catch (Exception ex) {
                return ex.ToString();
            }
        }

        //private string SaveASCIIFile(string fileName, string text) {
        //    try {
        //        FileInfo fi = new FileInfo(fileName);
        //        FileStream fs = fi.OpenWrite();
        //        // 
        //        fs.Write(bytes, 0, bytes.Length);
        //        fs.Close();
        //        fs.Dispose();
        //        return String.Empty;
        //    }
        //    catch (Exception ex) {
        //        return ex.ToString();
        //    }
        //}

        private string SaveShiftJISFile(string fileName, string text) {
            try {
                FileInfo fi = new FileInfo(fileName);
                FileStream fs = fi.OpenWrite();
                Encoding enc = Encoding.GetEncoding("Shift-Jis");
                byte[] bytes = enc.GetBytes(text);
                fs.Write(bytes, 0, bytes.Length);
                fs.Close();
                fs.Dispose();
                return String.Empty;
            }
            catch (Exception ex) {
                return ex.ToString();
            }
        }

        private void japaneseScriptAsUTF8ToolStripMenuItem_Click(object sender, EventArgs e) {
            DialogResult dr = saveFileDialog1.ShowDialog(this);
            if (dr != DialogResult.Cancel) {
                string error = SaveUTF8File(saveFileDialog1.FileName, txtJapanese.Text);
                if (!String.IsNullOrEmpty(error)) {
                    ShowMessageBox(this, error);
                }
            }
        }

        private void japaneseScriptAsShiftJISToolStripMenuItem_Click(object sender, EventArgs e) {
            DialogResult dr = saveFileDialog1.ShowDialog(this);
            if (dr != DialogResult.Cancel) {
                string error = SaveShiftJISFile(saveFileDialog1.FileName, txtJapanese.Text);
                if (!String.IsNullOrEmpty(error)) {
                    ShowMessageBox(this, error);
                }
            }
        }

        private void pasteAsUTF8ToolStripMenuItem_Click(object sender, EventArgs e) {
            if (Clipboard.ContainsText()) {
                SetText(txtJapanese, Clipboard.GetText());
            }
        }

        private void pasteAsShiftJISToolStripMenuItem_Click(object sender, EventArgs e) {
            if (Clipboard.ContainsText()) {
                string text = Clipboard.GetText();
                byte[] bytes = Encoding.UTF8.GetBytes(text);
                text = Encoding.GetEncoding("Shift-Jis").GetString(bytes);
                SetText(txtJapanese, text);
            }
        }

        private void CalculateColumnAndTile(int cursorIndex, int charsPerTile, TextBox textCtl, out int column, out int tile) {
            column = 0;
            tile = 0;

            // find out what line we're on
            // int lineNo = textCtl.GetLineFromCharIndex(cursorIndex);
        
            // go back to either a.) the beginning of the file or b.) the previous <LINE>
            int lineStart = Helpers.FindBeginningOfLine(textCtl.Text, cursorIndex);

            // now get the substring between the start of the line and the current position
            string subString = textCtl.Text.Substring(lineStart, cursorIndex - lineStart);

            // now find out how many characters between here and there are being used by commands
            // the commands regexp might help here

            // remove all those characters

            // now count the characters between here and there.  this is our column

            // now divide column by charsPerTile and Ceil it.  this is the tile number
            
        }

        private void timer1_Tick(object sender, EventArgs e) {
            int column = 0;
            int tile = 0;

            CalculateColumnAndTile(txtEnglish.SelectionStart + txtEnglish.SelectionLength, 2, txtEnglish, out column, out tile);

            SetText(englishColumn, String.Format(Messages.Column, column));
            SetText(englishTile, String.Format(Messages.Tile, tile));

            CalculateColumnAndTile(txtJapanese.SelectionStart + txtJapanese.SelectionLength, 1, txtJapanese, out column, out tile);

            SetText(japaneseColumn, String.Format(Messages.Column, column));
            SetText(japaneseTile, String.Format(Messages.Tile, tile));
        }
    }
}